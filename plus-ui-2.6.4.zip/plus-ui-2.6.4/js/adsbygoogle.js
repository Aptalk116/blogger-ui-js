/**
 * A dummy adsbygoogle.js file
 */
